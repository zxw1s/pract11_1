﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }

        private void Form1_Load (object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged (object sender, EventArgs e)
        {

        }
        public class Student
        {
            public string name;
            public double rost;
            private double ves=30;
            public double Geteat()
            {
                return ves;
            }
            public double SetEat(int eda,double ves)
            {
                if(eda>5 && eda<10)
                {
                    rost--;
                    this.ves = 70 % (eda * 1000 - 1600);
                }
                else
                    if (eda > 10)
                {
                    this.ves = 50 % (eda * 1000 - 1800);
                }
                else
                {
                    ves = ves + eda - 2800 / 1000;
                }
                return ves;
            }
        }

        private void button1_Click (object sender, EventArgs e)
        {
            Student student1 = new Student();
            student1.name = textBox1.Text;
            student1.rost = (double) (numericUpDown1.Value);
            student1.SetEat((int) numericUpDown3.Value,(int)numericUpDown2.Value);
            MessageBox.Show(string.Format("Студент:{0}\nРост:{1}\nВес:{2}\nсьеденной еды{3}кг", student1.name, student1.rost, student1.Geteat(),(int)numericUpDown3.Value));
        }

        private void textBox1_TextChanged (object sender, EventArgs e)
        {

        }
    }
}
